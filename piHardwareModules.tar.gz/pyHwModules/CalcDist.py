import Sonar

Sonar.init(8,10)

dist = Sonar.dist()

print(dist)
