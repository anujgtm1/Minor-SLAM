import numpy as np
import toCart

x = np.array([[45,1],[60,1],[30,1]],dtype=float)

toCart.toCartesian(x)

print(x)